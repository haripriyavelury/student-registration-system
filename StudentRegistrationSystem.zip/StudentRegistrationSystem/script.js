document.addEventListener("DOMContentLoaded", function() {  
    displayStudents();  
});  

let editIndex = null; // Store the index of the student being edited  


// validating student data entered in the form
function validateInput() {  
    let name = document.getElementById('name').value;  
    let studentId = document.getElementById('studentId').value;  
    let contact = document.getElementById('contact').value;  

    const nameError = document.getElementById('nameError');  
    const idError = document.getElementById('idError');  
    const contactError = document.getElementById('contactError');  

    nameError.textContent = /^[A-Za-z\s]+$/.test(name) ? '' : 'Invalid name. Only alphabets are allowed.';  
    idError.textContent = /^[0-9]+$/.test(studentId) ? '' : 'Invalid ID. Only numbers are allowed.';  
    contactError.textContent = /^[0-9]+$/.test(contact) ? '' : 'Invalid contact. Only numbers are allowed.';  

    return !(nameError.textContent || idError.textContent || contactError.textContent);  
}  


// Adding student details  
function registerStudent(event) {  
    event.preventDefault();  
    
    if (!validateInput()) return;  

    const students = JSON.parse(localStorage.getItem('students')) || [];  
    const newStudent = {  
        name: document.getElementById('name').value,  
        studentId: document.getElementById('studentId').value,  
        contact: document.getElementById('contact').value,  
        email: document.getElementById('email').value  
    };  

    
    if (editIndex !== null) {  
        // Update existing student  
        students[editIndex] = newStudent; // Directly replace the student at editIndex  
        alert('Student record updated successfully!');  
    } else {  
        // Add new student  
        students.push(newStudent);  
        alert('Student registered successfully!');  
    }  

    localStorage.setItem('students', JSON.stringify(students));  
 
    document.getElementById('studentForm').reset();  
    
    editIndex = null; // Reset the index after saving  
    displayStudents();  
}  

//displaying registered students

function displayStudents() {  
    const students = JSON.parse(localStorage.getItem('students')) || [];  
    const tbody = document.getElementById('studentTableBody');  
    tbody.innerHTML = '';  

    students.forEach((student, index) => {  
        const row = `<tr>  
                        <td>${student.name}</td>  
                        <td>${student.studentId}</td>  
                        <td>${student.contact}</td>  
                        <td>${student.email}</td>  
                        <td><button onclick="deleteStudent(${index})">Delete</button>
                        <button onclick="editStudent(${index})">Edit</button></td>  
                     </tr>`;  
        tbody.innerHTML += row;  
    });  

    document.getElementById('students').style.display = 'block';  
}  



function editStudent(index) {  
    const students = JSON.parse(localStorage.getItem('students')) || [];  
    const student = students[index];  

    document.getElementById('name').value = student.name;  
    document.getElementById('studentId').value = student.studentId;  
    document.getElementById('contact').value = student.contact;  
    document.getElementById('email').value = student.email;  

    editIndex = index; // Set the index for editing  
}  

function deleteStudent(index) {  
    const students = JSON.parse(localStorage.getItem('students')) || [];  
    students.splice(index, 1);  
    localStorage.setItem('students', JSON.stringify(students));  
    displayStudents();  
    alert('Student record deleted successfully!');
}  